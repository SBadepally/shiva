package com.systest.oms.controller;

import com.systest.oms.model.OrderItem;
import com.systest.oms.repository.OrderItemRepository;
import com.systest.oms.service.OrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orderitems")
public class OrderItemController {

    //autowire the OrderService class
    @Autowired
    OrderItemService orderService;
    @Autowired
    OrderItemRepository orderItemRepository;

    @GetMapping()
    public List<OrderItem> findAll() {
        return (List<OrderItem>) orderItemRepository.findAll();
    }
    @GetMapping(value="/{id}")
    public OrderItem findById(@PathVariable final Integer id) {
        return orderItemRepository.findById(id).get();
    }
    @GetMapping(value="/order/{id}")
    public List<OrderItem> findByOrder(@PathVariable final Integer id) {
        return orderItemRepository.findByOrder(id);
    }

    @PostMapping()
    public OrderItem load(@RequestBody final OrderItem orderItem) {
        orderItemRepository.save(orderItem);
        return orderItemRepository.findById(orderItem.getId().intValue()).get();
    }

    @PutMapping()
    public OrderItem update(@RequestBody final OrderItem orderItem) {
        orderItemRepository.save(orderItem);
        return orderItemRepository.findById(orderItem.getId().intValue()).get();
    }
    @DeleteMapping(value="/{id}")
    public OrderItem delete(@PathVariable final Integer id) {
        OrderItem customer=orderItemRepository.findById(id).get();
        orderItemRepository.delete(customer);
        return customer;

    }
    //creating a get mapping that retrieves all the books detail from the database
    @GetMapping("/orderitems")
    private List<OrderItem> getAllBooks()
    {
        return orderService.getOrderItems();
    }

}
