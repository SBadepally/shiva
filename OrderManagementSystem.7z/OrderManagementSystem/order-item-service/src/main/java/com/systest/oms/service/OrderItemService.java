package com.systest.oms.service;

import com.systest.oms.model.OrderItem;
import com.systest.oms.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderItemService {
    @Autowired
    OrderItemRepository orderItemRepository;

    public List<OrderItem> getOrderItems() {
        List<OrderItem> orderItems = new ArrayList<OrderItem>();
        orderItemRepository.findAll().forEach(orderItems1 -> orderItems.add(orderItems1));
        return orderItems;
    }
}
