package com.systest.oms.repository;

import com.systest.oms.model.OrderItem;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface OrderItemRepository extends CrudRepository<OrderItem, Integer> {
    @Query("select oi from OrderItem oi where oi.order.id = ?1")
    List<OrderItem> findByOrder(Integer orderId);

}
