package com.systest.oms.service;

import com.systest.oms.model.OrderItem;
import com.systest.oms.repository.OrderRepository;
import com.systest.oms.model.Order;
import com.systest.oms.rest.OrderItemsClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {
    @Autowired
    OrderRepository orderRepository;

    @Autowired(required = false)
    OrderItemsClient orderItemsClient;

    public List<Order> getOrders() {
        List<Order> orders = new ArrayList<Order>();
        orderRepository.findAll().forEach(orders1 -> orders.add(orders1));
        return orders;
    }

    //Using FeignClient fetching the orders from OrderItems
    public List<OrderItem> getOrderItems(Integer orderId) {
        List<OrderItem> orderItems = new ArrayList<OrderItem>();
        orderItemsClient.findByOrder(orderId);
        return orderItems;
    }
}
