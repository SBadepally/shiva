package com.systest.oms.controller;

import com.systest.oms.model.OrderItem;
import com.systest.oms.repository.OrderRepository;
import com.systest.oms.service.OrderService;
import com.systest.oms.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Locale;

@RestController
@RefreshScope
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    OrderService orderService;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    MessageSource messageSource;

    @GetMapping()
    public List<Order> findAll() {
        return (List<Order>) orderRepository.findAll();
    }

    /**
     * Using FeignClient, fetching the OrderItems
     * Error: If order id is not given, then it'll throw the Global exception
     */

    @GetMapping(value="/{id}")
    public Order findById(@PathVariable final Integer id) {
        if(id==null) {
            throw new RuntimeException(
                    messageSource.getMessage("order.id.required",null,  Locale.getDefault()));
        } else {
            Order order = orderRepository.findById(id).get();
            order.setOrderItems(orderService.getOrderItems(id));
            return order;
        }
    }

    @PostMapping()
    public Order load(@RequestBody final Order order) {
        orderRepository.save(order);
        return orderRepository.findById(order.getId().intValue()).get();
    }

    @PutMapping()
    public Order update(@RequestBody final Order order) {
        orderRepository.save(order);
        return orderRepository.findById(order.getId().intValue()).get();
    }
    @DeleteMapping(value="/{id}")
    public Order delete(@PathVariable final Integer id) {
        Order customer=orderRepository.findById(id).get();
        orderRepository.delete(customer);
        return customer;

    }



}
