package com.systest.oms.utils;

public class Response {
    Status status;
    String code;

    Response(Status status, String code) {
        this.status = status;
        this.code = code;
    }
}
