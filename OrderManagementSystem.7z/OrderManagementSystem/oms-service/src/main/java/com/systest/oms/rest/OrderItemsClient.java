package com.systest.oms.rest;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "OrderItemService", url = "http://localhost:9091")
public interface OrderItemsClient {

    @GetMapping("/orderitems")
    public List findAll();

    @GetMapping("/orderitems/order/{id}")
    public List findByOrder(@PathVariable final Integer id);
}
