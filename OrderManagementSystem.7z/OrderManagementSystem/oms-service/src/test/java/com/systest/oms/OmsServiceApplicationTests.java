package com.systest.oms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmsServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
