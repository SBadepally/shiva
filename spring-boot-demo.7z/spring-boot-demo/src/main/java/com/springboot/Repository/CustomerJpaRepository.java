package com.springboot.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.springboot.Model.Customers;

@Component
public interface CustomerJpaRepository extends JpaRepository<Customers, Long>  {
	
	Customers findByName(String name);
	
	Customers findByEmail(String email);

}
