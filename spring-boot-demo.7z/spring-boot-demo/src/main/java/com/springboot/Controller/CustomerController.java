package com.springboot.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.Model.Customers;
import com.springboot.Repository.CustomerJpaRepository;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	private CustomerJpaRepository customerJpaRepository;

	//@RequestMapping(method=RequestMethod.GET, value="/all")
	@GetMapping()
	public List<Customers> findAll(){
		return customerJpaRepository.findAll();
	}
	@GetMapping(value="/{name}")	
	public Customers findByName(@PathVariable final String name) {
		return customerJpaRepository.findByName(name);
	}
	
	@PostMapping()
	public Customers load(@RequestBody final Customers customers) {
		customerJpaRepository.save(customers);
		return customerJpaRepository.findByName(customers.getName());		
	}
	
	@PutMapping()
	public Customers update(@RequestBody final Customers customers) {
		customerJpaRepository.save(customers);
		return customerJpaRepository.findById(customers.getId()).get();
	}
	@DeleteMapping(value="/{id}")
	public Customers delete(@PathVariable final Long id) {
		Customers customer=customerJpaRepository.findById(id).get();
		 customerJpaRepository.delete(customer);
		return customer;
	
	}
}
